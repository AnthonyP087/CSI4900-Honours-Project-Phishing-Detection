function createResultTr(textList) {
    var newTr = document.createElement("tr");
    for (var i = 0; i < textList.length; i++) {
        var newTd = document.createElement("td");
    }
}



var pressCount = 0;

document.addEventListener("click", function (event) {
    if (!event.target.matches("#CentralButton")) return;
    console.log("Button was clicked!");
    var inputBarContent = document.getElementById("InputBar").value;

    console.log(inputBarContent=="");
    if (inputBarContent=="") {
            alert("Input for URL is empty! Please provide a string input.");
            return;
    }

    var dataa = {url: inputBarContent.toString()}



    pressCount++;
    var theTableBody = document.getElementById("ResultTableBody");
    var newTr = document.createElement("tr");

    //ID cell
    var newTd = document.createElement("td");
    var newContent = document.createTextNode(pressCount);
    newTd.appendChild(newContent);
    newTr.appendChild(newTd);

    //Date cell
    var newTd = document.createElement("td");
    var newContent = document.createTextNode(new Date().toLocaleString());
    newTd.appendChild(newContent);
    newTr.appendChild(newTd);


    //Input Bar cell
    var newTd = document.createElement("td");
    var newContent = document.createTextNode(document.getElementById("InputBar").value)
    var wrapperDiv = document.createElement("div");
    wrapperDiv.appendChild(newContent);
    wrapperDiv.style.maxWidth = "300";
    wrapperDiv.style.overflowX = "scroll";
    newContent = wrapperDiv;
    newTd.appendChild(newContent);
    newTr.appendChild(newTd);

    //API Payloard cell
    var newTd = document.createElement("td");
    let pdata = "API integration ongoing!";

    const request = new XMLHttpRequest();
    //request.open("GET", "https://api.csiproject.xyz/predicttest", false); // `false` makes the request synchronous
    request.open("POST", "https://api.csiproject.xyz/urlpredict", false);
    request.setRequestHeader('Content-Type','application/json');
    request.send(JSON.stringify(dataa))
    //request.send(null);
    if (request.status === 200) {
        console.log(request.status);
        pdata = request.responseText;
    }


    var newContent = document.createTextNode(pdata);
    newTd.appendChild(newContent);
    newTr.appendChild(newTd);


    theTableBody.insertBefore(newTr, theTableBody.firstChild);
    document.getElementById("ResultTable").style.display = "block";

    document.getElementById("InputBar").value="";

});
